
client_scripts{ 
	"client.lua"
}
